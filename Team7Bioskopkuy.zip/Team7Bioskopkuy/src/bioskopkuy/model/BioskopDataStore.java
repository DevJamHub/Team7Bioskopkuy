package bioskopkuy.model;

import bioskopkuy.service.BioskopException;
import java.util.*;

public class BioskopDataStore {

    public static class PaymentMethod {
        private String name; // Diubah menjadi non-final agar bisa di-update
        private int discountPercent;
        private String discountDescription;

        public PaymentMethod(String name, int discountPercent, String discountDescription) {
            this.name = name;
            this.discountPercent = discountPercent;
            this.discountDescription = discountDescription;
        }

        public String getName() {
            return name;
        }

        public int getDiscountPercent() {
            return discountPercent;
        }

        public String getDiscountDescription() {
            return discountDescription;
        }

        public void setDiscountPercent(int discountPercent) {
            this.discountPercent = discountPercent;
        }

        public void setDiscountDescription(String discountDescription) {
            this.discountDescription = discountDescription;
        }

        public void setName(String name) { // Tambahkan setter untuk name
            this.name = name;
        }

        @Override
        public String toString() {
            return name + (discountPercent > 0 ? " (" + discountPercent + "% Diskon - " + discountDescription + ")" : "");
        }
    }

    private final List<BioskopModel.Film> daftarFilm;
    private final Map<String, Set<String>> kursiTerisiMap;

    private List<PaymentMethod> daftarMetodePembayaran;

    public BioskopDataStore() {
        this.daftarFilm = new ArrayList<>();
        this.kursiTerisiMap = new HashMap<>();
        initializeDefaultData();
    }

    private void initializeDefaultData() {
        // Film default sekarang diinisialisasi di BioskopModel agar Film mengimplementasikan AbstractEntity

        this.daftarMetodePembayaran = new ArrayList<>();
        this.daftarMetodePembayaran.add(new PaymentMethod("Cash", 0, "Tidak Ada Diskon"));
        this.daftarMetodePembayaran.add(new PaymentMethod("Debit Card", 5, "Promo Debit BNI"));
        this.daftarMetodePembayaran.add(new PaymentMethod("GoodPay", 15, "Cashback 15% Max Rp15.000"));
    }

    public List<BioskopModel.Film> getDaftarFilm() {
        return Collections.unmodifiableList(daftarFilm);
    }

    public void addFilm(BioskopModel.Film film) throws BioskopException {
        for (BioskopModel.Film existingFilm : daftarFilm) {
            if (existingFilm.getJudul().equalsIgnoreCase(film.getJudul())) { // Tetap gunakan getJudul() karena itu public getter untuk nama
                throw new BioskopException("Film dengan judul '" + film.getJudul() + "' sudah ada.");
            }
        }
        daftarFilm.add(film);
    }

    public void removeFilm(BioskopModel.Film film) throws BioskopException {
        boolean removed = daftarFilm.remove(film);
        if (!removed) {
            throw new BioskopException("Film '" + film.getJudul() + "' tidak ditemukan."); // Gunakan getJudul()
        }
        List<String> keysToRemove = new ArrayList<>();
        for (String key : kursiTerisiMap.keySet()) {
            if (key.startsWith(film.getJudul() + "-")) { // Gunakan getJudul()
                keysToRemove.add(key);
            }
        }
        for (String key : keysToRemove) {
            kursiTerisiMap.remove(key);
        }
    }

    private String generateKursiKey(BioskopModel.Film film, String jam) {
        return film.getJudul() + "-" + jam; // Gunakan getJudul()
    }

    public boolean isKursiTerisi(BioskopModel.Film film, String jam, String kursiName) {
        String key = generateKursiKey(film, jam);
        Set<String> terisi = kursiTerisiMap.getOrDefault(key, Collections.emptySet());
        return terisi.contains(kursiName);
    }

    public void tandaiKursiTerisi(BioskopModel.Film film, String jam, Set<String> kursiNames) {
        String key = generateKursiKey(film, jam);
        kursiTerisiMap.computeIfAbsent(key, _ -> new HashSet<>()).addAll(kursiNames);
    }

    public void getAllKursiNames() {
        List<String> allKursi = new ArrayList<>();
        char[] rows = {'A', 'B', 'C', 'D'};
        int colCount = 10;
        for (char rowChar : rows) {
            for (int colIdx = 0; colIdx < colCount; colIdx++) {
                allKursi.add(String.valueOf(rowChar) + (colIdx + 1));
            }
        }
    }

    public List<PaymentMethod> getDaftarMetodePembayaran() {
        return Collections.unmodifiableList(daftarMetodePembayaran);
    }

    public void addMetodePembayaran(String name, int discountPercent, String discountDescription) throws BioskopException {
        if (name.trim().isEmpty()) {
            throw new BioskopException("Nama metode pembayaran tidak boleh kosong.");
        }
        for (PaymentMethod method : daftarMetodePembayaran) {
            if (method.getName().equalsIgnoreCase(name.trim())) {
                throw new BioskopException("Metode pembayaran '" + name + "' sudah ada.");
            }
        }
        if (discountPercent < 0 || discountPercent > 100) {
            throw new BioskopException("Persentase diskon harus antara 0-100.");
        }
        daftarMetodePembayaran.add(new PaymentMethod(name.trim(), discountPercent, discountDescription.trim()));
    }

    public void removeMetodePembayaran(PaymentMethod methodToRemove) throws BioskopException {
        if (!daftarMetodePembayaran.remove(methodToRemove)) {
            throw new BioskopException("Metode pembayaran '" + methodToRemove.getName() + "' tidak ditemukan.");
        }
    }

    public PaymentMethod updateMetodePembayaran(PaymentMethod originalMethod, String newName, int newDiscountPercent, String newDiscountDescription) throws BioskopException {
        if (newName.trim().isEmpty()) {
            throw new BioskopException("Nama metode pembayaran tidak boleh kosong.");
        }
        if (newDiscountPercent < 0 || newDiscountPercent > 100) {
            throw new BioskopException("Persentase diskon harus antara 0-100.");
        }

        for (PaymentMethod method : daftarMetodePembayaran) {
            if (method != originalMethod && method.getName().equalsIgnoreCase(newName.trim())) {
                throw new BioskopException("Nama metode pembayaran '" + newName + "' sudah digunakan.");
            }
        }

        originalMethod.setName(newName.trim());
        originalMethod.setDiscountPercent(newDiscountPercent);
        originalMethod.setDiscountDescription(newDiscountDescription.trim());
        return originalMethod;
    }


}